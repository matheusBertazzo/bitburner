/** @param {NS} ns */
export async function main(ns) {
	var ram = ns.args[0] || 8;
	var scriptName = ns.args[1] || 'hack.target.js';

	var serverCount = 0;

	// Continuously try to purchase servers until we've reached the maximum amount of servers
	while (serverCount < ns.getPurchasedServerLimit()) {    
		if (ns.getServerMoneyAvailable("home") > ns.getPurchasedServerCost(ram)) {        
			var hostname = ns.purchaseServer("pserv" , ram);

			ns.scp(scriptName, hostname);
			serverCount++;
		}

		await ns.sleep(1000);
	}
}