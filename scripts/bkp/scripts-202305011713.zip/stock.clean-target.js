/** @param {NS} ns */
export async function main(ns) {
	var target = ns.args[0] || 'foodnstuff';
	var stockSymbol = ns.args[1] || 'FNS';
	var serverDetails = ns.getServer(target);
	var moneyThreshold = serverDetails.moneyMax * 0.1;

	while (true) {
		var initialAskPrice = ns.stock.getAskPrice(stockSymbol);
		var initialBidPrice = ns.stock.getBidPrice(stockSymbol);

		await rampUp(ns, target);

		while (ns.getServerMoneyAvailable(target) > moneyThreshold) {
			await ns.hack(target, { stock: true });
		}

		log(ns, '=============== SUMMARY ===============');
		log(ns, 'Initial ask price: ' + initialAskPrice);
		log(ns, 'Final ask price: ' + ns.stock.getAskPrice(stockSymbol));
		log(ns, 'Initial bid price: ' + initialBidPrice);
		log(ns, 'Final bid price: ' + ns.stock.getBidPrice(stockSymbol));
		log(ns, '=======================================');

		await ns.sleep(1000);
	}
}

/** @param {NS} ns */
function log(ns, info) {
	var date = new Date();
	var info = '[' + date.toISOString() + '] ' + info + '\n'
	ns.write('/logs/stock.clean-target.log.txt', info, 'a');
}

async function rampUp(ns, target) {
	var securityThreshold = ns.getServerMinSecurityLevel(target) + 3;
	var moneyThreshold = ns.getServerMaxMoney(target) * 0.9;

	while (
		ns.getServerSecurityLevel(target) > securityThreshold
		|| ns.getServerMoneyAvailable(target) < moneyThreshold
	) {
		if (ns.getServerSecurityLevel(target) > securityThreshold) {
			log(ns, '========================');
			log(ns, 'Weakening server ' + target);
			log(ns, 'Progress: ' + ns.getServerSecurityLevel(target) + '/' + securityThreshold);
			log(ns, '========================');
			await ns.weaken(target);
			continue;
		}

		log(ns, '========================');
		log(ns, 'Growing server ' + target);
		log(ns, 'Progress: ' + ns.getServerMoneyAvailable(target) + '/' + moneyThreshold);
		log(ns, '========================');
		await ns.grow(target);
	}
}