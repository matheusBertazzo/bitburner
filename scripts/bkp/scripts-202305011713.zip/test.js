/** @param {NS} ns */
export async function main(ns) {
	ns.print(ns.hacknet.maxNumNodes());	
}