/** @param {NS} ns */
export async function main(ns) {
	let targetProperty = ns.args[0] || "level";
	let lastUpgradedNodeIndex = 0;

	while (true) {
		let amountOfNodes = ns.hacknet.numNodes();
		
		while(getUpgradeCost(ns, targetProperty, lastUpgradedNodeIndex) === Infinity) {
			ns.print('Node #' + lastUpgradedNodeIndex + ' is already at max level, going to the next one.');
			lastUpgradedNodeIndex++;
			
			if(lastUpgradedNodeIndex >= amountOfNodes) {
				return;
			}
		}

		while (ns.getPlayer().money > getUpgradeCost(ns, targetProperty, lastUpgradedNodeIndex)) {
			upgradeNode(ns, targetProperty, lastUpgradedNodeIndex);
			ns.print('Node #' + lastUpgradedNodeIndex + ' upgraded.');
			lastUpgradedNodeIndex++;

			if (lastUpgradedNodeIndex >= amountOfNodes) {
				lastUpgradedNodeIndex = 0;
			}
		}

		await ns.sleep(5000);
	}
}

function getUpgradeCost(ns, targetProperty, nodeIndex){
	if(targetProperty == "level"){
		return ns.hacknet.getLevelUpgradeCost(nodeIndex, 1);
	} else if (targetProperty == "ram") {
		return ns.hacknet.getRamUpgradeCost(nodeIndex, 1);
	} else {
		return ns.hacknet.getCoreUpgradeCost(nodeIndex, 1);
	}
}

/** @param {NS} ns */
function upgradeNode(ns, targetProperty, nodeIndex) {
	if(targetProperty == "level"){
		ns.hacknet.upgradeLevel(nodeIndex, 1);
	} else if (targetProperty == "ram") {
		ns.hacknet.upgradeRam(nodeIndex, 1);
	} else {
		ns.hacknet.upgradeCore(nodeIndex, 1);
	}
}