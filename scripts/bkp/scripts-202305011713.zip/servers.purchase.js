/** @param {NS} ns */
export async function main(ns) {
	var ram = ns.args[0] || 8;
	var serverCount = 0;

	while (serverCount < ns.getPurchasedServerLimit()) {
		if (ns.getServerMoneyAvailable("home") > ns.getPurchasedServerCost(ram)) {
			var hostname = ns.purchaseServer("pserv", ram);

			ns.scp(
				['hack.ramp-up.target.js', 'hack.target.js'],
				hostname
			);

			serverCount++;
		}

		await ns.sleep(1000);
	}
}